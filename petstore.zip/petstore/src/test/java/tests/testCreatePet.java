package tests;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import petstore.builders.PetBuilder;
import petstore.objects.Pet;
import org.testng.annotations.BeforeClass;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

public class testCreatePet {
	
	 enum Status
	 {available, pending, sold;
	 }

  // Specifies a default request specification that will be sent with each request	 
  RequestSpecification reqSpec = new RequestSpecBuilder()
				.setContentType(ContentType.JSON)
				.setAccept(ContentType.JSON)
				.setBaseUri("https://petstore.swagger.io/v2")
				.build();
  
  /* Test to verify pet gets created when sending post request 
   * with values for all fields in the request body
   */
  @Test
  public void positiveTestCase() {  
	 Pet pet1 = new PetBuilder().withAllFields().build();
	  
	 Pet retrievedPet =RestAssured.given()
				.contentType(ContentType.JSON)
				.accept(ContentType.JSON)
				//.baseUri("https://petstore.swagger.io/v2")
				.body(pet1)
				
				.when()
				.post("/pet")
				
	            .then()
	            .statusCode(200)
	            .extract().as(Pet.class);
	
	 assertEquals(retrievedPet.getId(),pet1.getId());
	 assertEquals(retrievedPet.getCategory().getId(), pet1.getCategory().getId()); 
	 assertEquals(retrievedPet.getCategory().getName(), pet1.getCategory().getName()); 
	 assertEquals(retrievedPet.getName(),pet1.getName());
	 assertEquals(retrievedPet.getPhotoUrls(), pet1.getPhotoUrls());
	 assertEquals(retrievedPet.getTags().get(0).getId(), pet1.getTags().get(0).getId());
	 assertEquals(retrievedPet.getTags().get(0).getName(), pet1.getTags().get(0).getName());
	 assertEquals(retrievedPet.getStatus(), pet1.getStatus());
  }
  
  /* Test to verify error response when sending invalid datatype 
   * for id in the post request
   */
  @Test
  public void negetiveTestCase() {  
	 Pet pet2 = new PetBuilder().withIdValueInvalidDatatype().build();
	  
	 RestAssured.given()
				.contentType(ContentType.JSON)
				.body(pet2)
				
				.when()
				.post("/pet")
				
	            .then()
	            .statusCode(500) // api should ideally return 405(invalid input) but currently it is incorrectly returning 500
	            .body("message", equalTo("something bad happened"));           
  }
  
  /* Test to verify error response when sending vary large value 
   * for id in the post request(Number/Character fuzzing)
   */
  @Test
  public void securityTestCase() {  
	 Pet pet2 = new PetBuilder().withVeryLargeValueForId().build();
	  
	 RestAssured.given()
				.contentType(ContentType.JSON)
				.body(pet2)
				
				.when()
				.post("/pet")
				
	            .then()
	            .statusCode(500) // api should ideally return 405(invalid input) but currently it is incorrectly returning 500
	            .body("message", equalTo("something bad happened"));	           
  }
}

