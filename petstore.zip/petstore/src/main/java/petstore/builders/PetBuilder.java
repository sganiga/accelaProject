package petstore.builders;


import java.util.ArrayList;
import java.util.List;

import petstore.objects.Category;
import petstore.objects.Pet;
import petstore.objects.Tags;

public class PetBuilder {
	Pet pet = new Pet();
	Category category = new Category();
	Tags tags =new Tags();
	List<Tags> allTags = new ArrayList<Tags>();
	String[] photoUrls = {"http://petstore/images/1"};
	
	public PetBuilder withAllFields() {
		pet.setId("1");
		category.setId(1);
		category.setName("dogs");
		pet.setCategory(category);
		pet.setName("sando");
		pet.setPhotoUrls(photoUrls);
		tags.setId(1);
		tags.setName("friendly");
		allTags.add(tags);
		pet.setTags(allTags);
		pet.setStatus(Pet.Status.available);
		return this;
	}
	
	public PetBuilder withIdValueInvalidDatatype() {
		pet.setId("gdgd");
		category.setId(1);
		category.setName("dogs");
		pet.setCategory(category);
		pet.setName("sando");
		pet.setPhotoUrls(photoUrls);
		tags.setId(1);
		tags.setName("friendly");
		allTags.add(tags);
		pet.setTags(allTags);
		pet.setStatus(Pet.Status.available);
		return this;
	}
	
	public PetBuilder withVeryLargeValueForId() {
		pet.setId("53535353552522535352");
		category.setId(1);
		category.setName("dogs");
		pet.setCategory(category);
		pet.setName("sando");
		pet.setPhotoUrls(photoUrls);
		tags.setId(1);
		tags.setName("friendly");
		allTags.add(tags);
		pet.setTags(allTags);
		pet.setStatus(Pet.Status.available);
		return this;
	}
//	
	public Pet build() {
		return pet;
	}
	
}
