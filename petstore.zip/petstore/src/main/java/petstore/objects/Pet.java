package petstore.objects;

import java.util.List;

public class Pet {
	private String id;
	private Category category;	
    private String name;
    private String[] photoUrls;
    private List<Tags> tags;
    private String status;
    
    // Enum declared for all the allowed values of status
    public enum Status
	 {available, pending, sold;
	 }
    
	public String getId() {
		return id;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String[] getPhotoUrls() {
		return photoUrls;
	}
	public void setPhotoUrls(String[] photoUrls) {
		this.photoUrls = photoUrls;
	}
	public List<Tags> getTags() {
		return tags;
	}
	public void setTags(List<Tags> tags) {
		this.tags = tags;
	}
	
	public void setId(String id) {
		this.id = id;
	} 
	
	public String getStatus() {
		return status;
	}	
	public void setStatus(Status status) {
		this.status = status.toString();
	}
}